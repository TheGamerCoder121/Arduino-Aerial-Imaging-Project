#include <EYW_alt.h>
#include <Wire.h>


 
//****************************************************************************************************
//---------------------------------------Altimeter Functions------------------------------------------
//****************************************************************************************************
 
char EYW_alt::Altimeter::begin()
// Initialize library for subsequent pressure measurements
{
	float c3,c4,b1;

	
	//set the default pin #s
	buttonPin = 2;
	ledPin = 4;
	speakerPin = 5;

	//set the pinModes
	pinMode(buttonPin, INPUT);
	pinMode(ledPin, OUTPUT);
	pinMode(speakerPin, OUTPUT);
	
	//sets the AREF pin to external. Note that if nothing is connected to this pin
	//that the returned ADC values will not be accurate
	analogReference(EXTERNAL);
	 
	//The serial monitor is NOT hard coded to begin
	//Users should explicitly call this in their sketch
	//to read the calibration data
	//Serial.begin(9600);
	
	Serial.println("Altimeter Started!");
	
	
	// Start up the Arduino's "wire" (I2C) library:
	 
	Wire.begin();
	 
	// The BMP180 includes factory calibration data stored on the device.
	// Each device has different numbers, these must be retrieved and
	// used in the calculations when taking pressure measurements.
	 
	// Retrieve calibration data from device:
	 
	if (readInt(0xAA,AC1) &&
	readInt(0xAC,AC2) &&
	readInt(0xAE,AC3) &&
	readUInt(0xB0,AC4) &&
	readUInt(0xB2,AC5) &&
	readUInt(0xB4,AC6) &&
	readInt(0xB6,VB1) &&
	readInt(0xB8,VB2) &&
	readInt(0xBA,MB) &&
	readInt(0xBC,MC) &&
	readInt(0xBE,MD))
	{
		 
		c3 = 160.0 * pow(2,-15) * AC3;
		c4 = pow(10,-3) * pow(2,-15) * AC4;
		b1 = pow(160,2) * pow(2,-30) * VB1;
		c5 = (pow(2,-15) / 160) * AC5;
		c6 = AC6;
		mc = (pow(2,11) / pow(160,2)) * MC;
		md = MD / 160.0;
		x0 = AC1;
		x1 = 160.0 * pow(2,-13) * AC2;
		x2 = pow(160,2) * pow(2,-25) * VB2;
		y0 = c4 * pow(2,15);
		y1 = c4 * c3;
		y2 = c4 * b1;
		p0 = (3791.0 - 8.0) / 1600.0;
		p1 = 1.0 - 7357.0 * pow(2,-20);
		p2 = 3038.0 * 100.0 * pow(2,-36);
		 
		 
		return(1);
	}
	else
	{
		// Error reading calibration data; bad component or connection?
		return(0);
	}
}


//Overloaded function to accept pin #s for the button, led, and speaker
char EYW_alt::Altimeter::begin(int bP, int lP, int sP)
// Initialize library for subsequent pressure measurements
{
	float c3,c4,b1;
	
	//set the pin #s to the user provided values
	buttonPin = bP;
	ledPin = lP;
	speakerPin = sP;
	
	//set the pinModes
	pinMode(buttonPin, INPUT);
	pinMode(ledPin, OUTPUT);
	pinMode(speakerPin, OUTPUT);

	//sets the AREF pin to external. Note that if nothing is connected to this pin
	//that the returned ADC values will not be accurate
	analogReference(EXTERNAL);

	//The serial monitor is NOT hard coded to begin
	//Users should explicitly call this in their sketch
	//to read the calibration data
	//Serial.begin(9600);
	
	Serial.println("Altimeter Started!");
	Serial.print("Button Attached To Pin # ");
	Serial.println(buttonPin);				
	Serial.print("LED Attached To Pin # ");
	Serial.println(ledPin);
	Serial.print("Speaker Attached To Pin # ");
	Serial.println(speakerPin);
	 
	// Start up the Arduino's "wire" (I2C) library:
	 
	Wire.begin();
	 
	// The BMP180 includes factory calibration data stored on the device.
	// Each device has different numbers, these must be retrieved and
	// used in the calculations when taking pressure measurements.
	 
	// Retrieve calibration data from device:
	 
	if (readInt(0xAA,AC1) &&
	readInt(0xAC,AC2) &&
	readInt(0xAE,AC3) &&
	readUInt(0xB0,AC4) &&
	readUInt(0xB2,AC5) &&
	readUInt(0xB4,AC6) &&
	readInt(0xB6,VB1) &&
	readInt(0xB8,VB2) &&
	readInt(0xBA,MB) &&
	readInt(0xBC,MC) &&
	readInt(0xBE,MD))
	{
		 
		c3 = 160.0 * pow(2,-15) * AC3;
		c4 = pow(10,-3) * pow(2,-15) * AC4;
		b1 = pow(160,2) * pow(2,-30) * VB1;
		c5 = (pow(2,-15) / 160) * AC5;
		c6 = AC6;
		mc = (pow(2,11) / pow(160,2)) * MC;
		md = MD / 160.0;
		x0 = AC1;
		x1 = 160.0 * pow(2,-13) * AC2;
		x2 = pow(160,2) * pow(2,-25) * VB2;
		y0 = c4 * pow(2,15);
		y1 = c4 * c3;
		y2 = c4 * b1;
		p0 = (3791.0 - 8.0) / 1600.0;
		p1 = 1.0 - 7357.0 * pow(2,-20);
		p2 = 3038.0 * 100.0 * pow(2,-36);
		 
		 
		return(1);
	}
	else
	{
		// Error reading calibration data; bad component or connection?
		return(0);
	}
}

char EYW_alt::Altimeter::readInt(char address, int &value)
// Read a signed integer (two bytes) from device
// address: register to start reading (plus subsequent register)
// value: external variable to store data (function modifies value)
{
	unsigned char data[2];
	 
	data[0] = address;
	if (readBytes(data,2))
	{
		value = (((int)data[0]<<8)|(int)data[1]);
		//if (*value & 0x8000) *value |= 0xFFFF0000; // sign extend if negative
		return(1);
	}
	value = 0;
	return(0);
}
 

//The following four functions all pertain to reading data from an i2c device
//*****************************************************************************

char EYW_alt::Altimeter::readUInt(char address, unsigned int &value)
// Read an unsigned integer (two bytes) from device
// address: register to start reading (plus subsequent register)
// value: external variable to store data (function modifies value)
{
	unsigned char data[2];
	 
	data[0] = address;
	if (readBytes(data,2))
	{
		value = (((unsigned int)data[0]<<8)|(unsigned int)data[1]);
		return(1);
	}
	value = 0;
	return(0);
}
 
 
char EYW_alt::Altimeter::readBytes(unsigned char *values, char length)
// Read an array of bytes from device
// values: external array to hold data. Put starting register in values[0].
// length: number of bytes to read
{
	char x;
	 
	Wire.beginTransmission(BMP180_ADDR);
	Wire.write(values[0]);
	_error = Wire.endTransmission();
	if (_error == 0)
	{
		Wire.requestFrom(BMP180_ADDR,length);
		while(Wire.available() != length) ; // wait until bytes are ready
		for(x=0;x<length;x++)
		{
			values[x] = Wire.read();
		}
		return(1);
	}
	return(0);
}
 
 
char EYW_alt::Altimeter::writeBytes(unsigned char *values, char length)
// Write an array of bytes to device
// values: external array of data to write. Put starting register in values[0].
// length: number of bytes to write
{
	Wire.beginTransmission(BMP180_ADDR);
	Wire.write(values,length);
	_error = Wire.endTransmission();
	if (_error == 0)
	return(1);
	else
	return(0);
}
 
//*******************************************************************************
//
//The Following six functions are from Sparkfun's BMP180 library and rely on the Bosch data sheet and coeffecients 
//
//*******************************************************************************

char EYW_alt::Altimeter::startTemperature(void)
// Begin a temperature reading.
// Will return delay in ms to wait, or 0 if I2C error
{
	unsigned char data[2], result;
	 
	data[0] = BMP180_REG_CONTROL;
	data[1] = BMP180_COMMAND_TEMPERATURE;
	result = writeBytes(data, 2);
	if (result) // good write?
	return(5); // return the delay in ms (rounded up) to wait before retrieving data
	else
	return(0); // or return 0 if there was a problem communicating with the BMP
}
 
 
char EYW_alt::Altimeter::getTemperature(float &T)
// Retrieve a previously-started temperature reading.
// Requires begin() to be called once prior to retrieve calibration parameters.
// Requires startTemperature() to have been called prior and sufficient time elapsed.
// T: external variable to hold result.
// Returns 1 if successful, 0 if I2C error.
{
	unsigned char data[2];
	char result;
	float tu, a;
	 
	data[0] = BMP180_REG_RESULT;
	 
	result = readBytes(data, 2);
	if (result) // good read, calculate temperature
	{
		tu = (data[0] * 256.0) + data[1];
		a = c5 * (tu - c6);
		T = a + (mc / (a + md));
		 
	}
	return(result);
}
 
 
char EYW_alt::Altimeter::startPressure(char oversampling)
// Begin a pressure reading.
// Oversampling: 0 to 3, higher numbers are slower, higher-res outputs.
// Will return delay in ms to wait, or 0 if I2C error.
{
	unsigned char data[2], result, delay;
	 
	data[0] = BMP180_REG_CONTROL;
	 
	switch (oversampling)
	{
		case 0:
		data[1] = BMP180_COMMAND_PRESSURE0;
		delay = 5;
		break;
		case 1:
		data[1] = BMP180_COMMAND_PRESSURE1;
		delay = 8;
		break;
		case 2:
		data[1] = BMP180_COMMAND_PRESSURE2;
		delay = 14;
		break;
		case 3:
		data[1] = BMP180_COMMAND_PRESSURE3;
		delay = 26;
		break;
		default:
		data[1] = BMP180_COMMAND_PRESSURE0;
		delay = 5;
		break;
	}
	result = writeBytes(data, 2);
	if (result) // good write?
	return(delay); // return the delay in ms (rounded up) to wait before retrieving data
	else
	return(0); // or return 0 if there was a problem communicating with the BMP
}
 
 
char EYW_alt::Altimeter::getPressure(float &P, float &T)
// Retrieve a previously started pressure reading, calculate abolute pressure in mbars.
// Requires begin() to be called once prior to retrieve calibration parameters.
// Requires startPressure() to have been called prior and sufficient time elapsed.
// Requires recent temperature reading to accurately calculate pressure.
 
// P: external variable to hold pressure.
// T: previously-calculated temperature.
// Returns 1 for success, 0 for I2C error.
 
// Note that calculated pressure value is absolute mbars, to compensate for altitude call sealevel().
{
	unsigned char data[3];
	char result;
	float pu,s,x,y,z;
	 
	data[0] = BMP180_REG_RESULT;
	 
	result = readBytes(data, 3);
	if (result) // good read, calculate pressure
	{
		pu = (data[0] * 256.0) + data[1] + (data[2]/256.0);
		 
		s = T - 25.0;
		x = (x2 * pow(s,2)) + (x1 * s) + x0;
		y = (y2 * pow(s,2)) + (y1 * s) + y0;
		z = (pu - x) / y;
		P = (p2 * pow(z,2)) + (p1 * z) + p0;
	}
	return(result);
}

float EYW_alt::Altimeter::sealevel(float P, float A)
// Given a pressure P (mb) taken at a specific altitude (meters),
// return the equivalent pressure (mb) at sea level.
// This produces pressure readings that can be used for weather measurements.
{
	return(P/pow(1-(A/44330.0),5.255));
}
 
 
float EYW_alt::Altimeter::altitude(float P, float P0)
// Given a pressure measurement P (mb) and the pressure at a baseline P0 (mb),
// return altitude (meters) above baseline.
{
	return(44330.0*(1-pow(P/P0,1/5.255)));
}
 
 
char EYW_alt::Altimeter::getError(void)
// If any library command fails, you can retrieve an extended
// error code using this command. Errors are from the wire library:
// 0 = Success
// 1 = Data too long to fit in transmit buffer
// 2 = Received NACK on transmit of address
// 3 = Received NACK on transmit of data
// 4 = Other error
{
	return(_error);
}

//***************************************************************************************************

char EYW_alt::Altimeter::calibrate(int num)
//Given a number 'num' the calibration scheme will take average measurements of
//a baseline zero alititude.
{
	float temperature;
	float pressure;
	float total = 0;
	for (int i=0; i<num; i++)
	{
		startTemperature();
		delay(5);//factory delay recommendation
		getTemperature(temperature);
		startPressure(3);
		delay(26);//factory delay recommendation
		getPressure(pressure,temperature);
		total += sealevel(pressure,0.0);
		 
	}
	baselineSLP = total/(float)num;
	if (baselineSLP != -999.99) return 1; //check if the calibration scheme has been correctly run
	else return 0;
}
char EYW_alt::Altimeter::calibrate(int num, float filterVal)
//Given a number num the calibration scheme will take num measurements of
//a baseline zero alititude. Optionally, set the low pass filter with filterVal
//filterVal is 0.0 - 1.0 and defaults to 1.0 (filter is off)
//This should only be used for advanced debugging
{
	float temperature;
	float pressure;
	float avArray[num];
	float heightLPF;
	float total;
	for (int i=0; i<num; i++)
	{
		startTemperature();
		delay(5);//factory delay recommendation
		getTemperature(temperature);
		startPressure(3);
		delay(26);//factory delay recommendation
		getPressure(pressure,temperature);
		avArray[i] = sealevel(pressure,0.0);
		//initializes the first value of the LPF to the first reading
		if (i==0) heightLPF = avArray[0];
		//Low Pass Filter algorithm
		if (filterVal < 1)
		{
			heightLPF = (avArray[i] * filterVal) + (heightLPF * (1 - filterVal));
			avArray[i] = heightLPF;
		}
	}

	//take the average of the low pass filtered values
	for (int i = 0; i < num; i++)
	{
		total += avArray[i];
	}
	baselineSLP = total / float(num);
	if (baselineSLP != -999.99) return 1; //check if the calibration scheme has been correctly run
	else return 0;
}
 
void EYW_alt::Altimeter::alarm(void)
//Sounds the alititude alarm on the specified pin number
//Defaults to 2 tones, at 880 Hz, for 1/4 second each
{
	int num = 2;
	int freq = 880;
        int duration = 250;
	//play the tone num times at freq frequency for dur milliseconds
	for (int i = 0; i < num; i++)
	{
		digitalWrite(ledPin,HIGH);
		tone(speakerPin, freq, duration); delay(duration);
		digitalWrite(ledPin,LOW);
		delay(duration);
	}
}

void EYW_alt::Altimeter::alarm(int num, int freq, int dur)
//Sounds the altitude alarm on pinNum for 'num' times at 'freq' frequency for dur duration
{
	int duration = dur;
	//play the tone num times at freq frequency for dur milliseconds
	for (int i = 0; i < num; i++)
	{
		digitalWrite(ledPin,HIGH);
		tone(speakerPin, freq, duration); delay(duration);
		digitalWrite(ledPin,LOW);
		delay(duration);
	}
}

float EYW_alt::Altimeter::getHeight(void)
//retrieves the current altitude reading and returns the value in feet
//uses the calibration scheme to reference zero height
{
	float temperature, pressure, height;
	 
	startTemperature();
	delay(5);
	getTemperature(temperature);
	startPressure(3);
	delay(26);
	getPressure(pressure,temperature);
	height = altitude(pressure, baselineSLP);
	return (height);
	 
}
 
float EYW_alt::Altimeter::getHeightAvg(int num)
//runs getHeight 'num' times and averages those readings
//returns the average current altitude in feet
{
	float temperature, pressure, height, total = 0;
	 
	for (int i = 0; i < num; i++)
	{
		startTemperature();
		delay(5);
		getTemperature(temperature);
		startPressure(3);
		delay(26);
		getPressure(pressure,temperature);
		total += altitude(pressure, baselineSLP); //add all the measurements together
	}
	 
	height = total / num; //divide the total by the number to get the mean
	return (height);
}
 

void EYW_alt::Altimeter::led(int status)
//controls the LED on the defined led pin #
//takes an argument of true/HIGH/1 and false/LOW/0
{
	if (status == 1) digitalWrite(ledPin, HIGH);
	else if (status == 0) digitalWrite(ledPin, LOW);
	else return;
}